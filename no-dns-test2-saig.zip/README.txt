no-dns-test2-saig.conf - Windows / Linux / macOs / Mobile
Normal config this should work with all devices if not have any issue.

no-dns-test2-saig-linux.conf - Linux.
Fix for some linux that unable to use the VPN DNS. 

How to Use

Windows / macOs / Mobile
Import the no-dns-test2-saig.conf file into your WireGuard client application.

Linux (wg-quick)
1. sudo cp no-dns-test2-saig-linux.conf /etc/wireguard/saig.conf
2. sudo wg-quick up saig
