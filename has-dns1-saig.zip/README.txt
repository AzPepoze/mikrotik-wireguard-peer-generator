has-dns1-saig.conf - Windows / Linux / macOs / Mobile
Normal config this should work with all devices if not have any issue.

has-dns1-saig-linux.conf - Linux.
Fix for some linux that unable to use the VPN DNS. 

has-dns1-saig-no-dns.conf - Windows / Linux / macOs / Mobile
Use this if you don't want to use the VPN DNS.

How to Use

Windows / macOs / Mobile
Import the has-dns1-saig.conf file into your WireGuard client application.

Linux (wg-quick)
1. sudo cp has-dns1-saig-linux.conf /etc/wireguard/saig.conf
2. sudo wg-quick up saig

* NOTE : VPN DNS is for able to use servername instead of ip.
